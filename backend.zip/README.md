# ScanPulse
QR Code based polling service: in the real world, take a poster board and ask a question like “How are you feeling today?” And then have 3 QR codes with emojis (sad, neutral, happy) under them. When users scan the code, they’re redirected to a website that visualizes results of the poll, where each scan corresponds to a vote. 
